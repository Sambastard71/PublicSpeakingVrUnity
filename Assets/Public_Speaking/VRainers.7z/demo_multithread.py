import pickle
import threading
from threading import Thread

import pyttsx3
import speech_recognition as sr
import pandas as pd
from gensim.models import Doc2Vec
from gensim.models.doc2vec import TaggedDocument
from nltk.tokenize import word_tokenize
from sklearn.linear_model import LogisticRegression
from stop_words import get_stop_words

threadLock = threading.Lock()

'''
Classe per il thread di ascolto utente. 
Questa classe fornisce tutti i metodi per ascoltare la frase utente e convertirla in testo
'''


class Listener_thread(Thread):
    def __init__(self, ):
        Thread.__init__(self)
        # inizializzo microfono e interprete
        recognizer = sr.Recognizer()
        microphone = sr.Microphone()
        self.recognizer = recognizer
        self.microphone = microphone


    def run(self):
        '''
        sentence_status indica se la parola è stata pronunciata oppure no
        0 - Parola non pronunciata (quindi il thred di speaking non prende la lock)
        1 - parola pronunciata
        -1 - il segnale audio non viene convertito in testo, errore

        mentre sentence è la var globale che conterrà la parola
        '''

        print("Thread ascolto avviato")
        global sentence, sentence_status
        sentence = ""
        sentence_status = 0
        global exit_lesson
        exit_lesson = False
        while True:
            if exit_lesson:
                break
            if sentence_status == 0:

                threadLock.acquire()
                with self.microphone as source:
                    self.recognizer.adjust_for_ambient_noise(source)
                    print("[Puoi parlare]")
                    audio = self.recognizer.listen(source)
                try:
                    sentence = self.recognizer.recognize_google(audio, language="it-IT")
                    sentence_status = 1
                except:
                    sentence_status = -1
                threadLock.release()



'''
Classe per il thread di analisi frase utente e scelta della lezione. 
Questa classe fornisce tutti i metodi per analizzare la richiesta utente trasformata in testo e riprodurre
la corretta sezione richiesta 
'''


class Speaker_thread(Thread):
    def __init__(self, model_input, logreg_input, path_dir_lezioni):
        Thread.__init__(self)

        self.model = model_input
        '''
        logreg è il modello di regressione usato per fare la classificazione finale.
        '''
        self.logreg = logreg_input
        self.path_lezioni = path_dir_lezioni
        self.id_section = 0
        self.stop_words = get_stop_words('italian')

        print("Salve Utente, benvenuto in VRAINERS.")
        print("Ogni volta che apparirà a schermo la scritta [Puoi parlare] ")
        print("allora potrai comunicare con l'Avatar vocalmente.")
        print("Quando ti senti pronto, semplicemente chiedere di iniziare la lezione usando la tua voce.")

    def preprocess(self, doc):
        doc = doc.lower()  # Lower the text.
        doc = word_tokenize(doc)  # Split into words.
        doc = [w for w in doc if not w in self.stop_words]  # Remove stopwords.
        doc = [w for w in doc if w.isalpha()]  # Remove numbers and punctuation.
        return doc

    def vec_for_classification(self, sentence):
        '''
        :param sentence: frase da classificare
        :return: classe a cui appartiene quella frase, ad esemoio la frase inizio appartiene alla classe 1
        che indica che la lezione deve iniziare
        '''
        s = self.preprocess(sentence)
        regressors = [self.model.infer_vector(s, steps=20)]
        return regressors

    def analyse_text(self, sentence):
        '''
        :param sentence: frase da analizzare
        :return: codice della risposta

        codici risposte:
        1 - Esegui Intro
        2 - Ripeti modulo
        3 - Avanti al prossimo modulo
        70 - utente ha detto una frase non legata ad una opzione
        80 - utente vuole uscire
        '''

        print("sto elaborando la seguente frase:")
        print("-> " + sentence)

        vec_sentence = self.vec_for_classification(sentence)
        pred = self.logreg.predict(vec_sentence)
        perc_pred = self.logreg.predict_proba(vec_sentence)
        prob = max(perc_pred[0])

        print("Classificato come: " + str(pred[0]) + ", con probabilità: " + str(prob))

        id_response = 70  # id di default
        if prob >= 0.5:
            id_response = pred[0]

        return id_response

    '''
    Questa funzione gestisce la logica di esecuzione di una lezione.
    Cambiando lezione o cambiando ordine delle sezioni bisogna lavorare su questa funzione e sui metodi che 
    richiama a sua volta
    '''

    def lesson_tree(self, local_sentence):
        """
        questa funzione decide la logica della lezione e come gestire i comandi che un utente può dare

        codici risposte:
        1 - Esegui Intro
        2 - Ripeti modulo
        3 - Avanti al prossimo modulo
        70 - utente ha detto una frase non legata ad una opzione
        80 - utente vuole uscire

        codici comandi in base alle risposte:
        1 - esegui Introduzione (solo inizio programma)
        2 - Ripeti questa lezione
        3 - Procedi a successiva
        70 - Opzione non presente, quindi ripete frase utente e dice che non è presente tra le scelte
        80 - Esci dal corso - Gestista al di fuori di questa funzione
        404 - Frase non compresa (errore nel convertire text2speech) - Gestista al di fuori di questa funzione

        i codici vengono trattati separatamente in quanto un utente può fare una determinata richiesta
        che potrebbe non essere consentita per l'attuale parte della lezione
        quindi quella richiesta con un determinato id sarà gestita con un comando apposito
        inoltre questo sistema predispone già scenari a selezione multipla o scenario a grafo
        """
        next_section = -1
        command = -1

        id_resp = self.analyse_text(local_sentence)

        if id_resp == 80:
            command = 80
            next_section = 0
        else:
            if id_resp == 70:
                command = 70
                next_section = self.id_section

            if id_resp == 1 and self.id_section == 0:
                command = 1
                next_section = 1

            if id_resp == 2 and 1 <= self.id_section < 6:
                command = 2
                next_section = self.id_section

            if id_resp == 3 and 1 <= self.id_section < 5:
                command = 3
                next_section = self.id_section + 1

            if id_resp == 3 and self.id_section == 5:
                command = 101
                next_section = 80

        return command, next_section

    def execute_command(self, command):
        '''
        questa funzione esegue il comando, ovvero in base al comando leggerà una delle lezioni presenti nel path
        indicato in fase di init. Qui può essere generato il file mp3 e qui bisognerà lavorare per gestire
        l'interazione con unity.
        :param command: comando che indica quale documento leggere o quale frase di avvertenza dire
        :return: al momento torna 1 per indicare che va tutto bene, dovrò mettere vari dei try e catch sulle istruzioni
        del text2speach cosi in caso di errore torna -1 e si possono gestire gli errori
        '''
        print("esecuzione di command: " + str(command) + " id lezione: " + str(self.id_section))

        #setto voce e velocità di esecuzione
        eng = pyttsx3.init()
        eng.setProperty('voice',
                        'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech\Voices\Tokens\TTS_MS_IT-IT_ELSA_11.0')
        eng.setProperty('rate', 150)

        if self.id_section == 0 and command != 1 and command < 70:
            print("Caro Utente, per iniziare ti ricordo che devi chiedere chiaramente di iniziare la lezione.")
        else:
            if command < 70:
                fileindex = str(self.id_section)
            else:
                fileindex = str(command)

            with open(self.path_lezioni + "/" + fileindex + ".txt") as f:

                for line in f:
                    # test api di google con voce maschile
                    '''
                    tts = gTTS(line)
                    filename = 'audio_temp/temp.mp3'
                    tts.save(filename)
                    music = pyglet.media.load(filename, streaming=False)
                    music.play()
                    sleep(music.duration)  # prevent from killing
                    os.remove(filename)  # remove temperory file
                    '''

                    #si appoggia al simulatore windows di voce
                    #leggo riga per riga
                    eng.say(line)
                    eng.runAndWait()
                return 1


    def run(self):
        global exit_lesson
        exit_lesson = False
        print("Thread lezione avviato")
        global sentence, sentence_status
        sentence = ""
        sentence_status = 0
        while True:

            if sentence_status == 0:
                continue

            if sentence_status == 1:
                '''
                da qui io so che una frase è stata detta, quindi uso il lock per dire che la CPU appartiene solo 
                al thread di speaking
                '''
                threadLock.acquire()
                print("[Esecuzione Avatar]")
                local_sentence = sentence
                aa = 0
                command, self.id_section = self.lesson_tree(local_sentence)
                self.execute_command(command)

                if command == 80:
                    "APPLICAZIONE IN CHIUSURA"
                    exit_lesson = True

                #svuoto la frase ed indico che non ci sono altre frasi utente cambiando lo stato della sentence
                #(mettendolo a zero), in modo da rimettersi in attesa che il listener elabori una nuova frase
                sentence_status = 0
                sentence = ""
                threadLock.release()
                if exit_lesson:
                    break

            if sentence_status == -1:
                #frase pronunciata male e non trasformabile in testo.
                #al momento ho fatto una gestione separata in caso che in futuro si voglia gestire tale casistica
                #in un altro modo

                threadLock.acquire()
                command = 404
                self.execute_command(command)
                sentence_status = 0
                threadLock.release()


def vec_for_learning(model, tagged_docs):
    '''

    :param model: modello doc2vec
    :param tagged_docs: parole da usare per addestrare con i loro tag (ovvero le classi di appartenenza)
    :return: torna la lista dei tag per ogni frase e le frasi tramutate in regressori

    il regressore è un vettore di elementi in input X = [[x1],[x2],[x3],...], il modello logistico vuole
    un vettore di vettori come input, dove ogni elemento è il risultato dell'elaborazione con il modello doc2vec

    '''
    sents = tagged_docs.values
    targets, regressors = zip(*[(doc.tags[0], model.infer_vector(doc.words, steps=20)) for doc in sents])
    return targets, regressors


def preprocess(doc, stop_words):
    '''
    questa funzione purtroppo l'ho dovuta replicare fuori dal thread di speaking perchè non potendo caricare il
    modello logistico da file, e dovendolo riaddestrare al volo prima dell'esecuzione, allora devo caricarmi i dati
    e pre-processarli. Devo trovare una soluzione per questo in futuro

    :param doc: documento da pre-processare per essere elaborato con il doc2vec
    :param stop_words: le parole da rimuovere perchè non utili alla semantica (tipo gli articoli ad esempio)
    :return: documento suddiviso in token (vettore di singole parole) con stopword rimosse e tutto in lowercase
    '''
    doc = doc.lower()  # Lower the text.
    doc = word_tokenize(doc)  # Split into words.
    doc = [w for w in doc if not w in stop_words]  # Remove stopwords.
    doc = [w for w in doc if w.isalpha()]  # Remove numbers and punctuation.
    return doc


def carica_modello(path_modello, csv_path):
    '''
    puoi controllare il file csv, apribile con excel o un editor di testo per vedere le classi e le frasi usate in
    training
    :param path_modello:  path dove ho salvato il modello doc2vec addestrato
    :param csv_path: path dove è salvato il cvs usato per addestrare il modello e la regressione logistica
    :return: modello addeestrato con pesi caricati e modello di regressione addestrato
    '''
    model = Doc2Vec.load(path_modello + "/doc2vec_model_04_02_2020")

    #pkl_filename = path_modello + "/logreg_model_04_02_2020.pkl"

    df = pd.read_csv(csv_path)
    df = df[['risposta', 'classe']]
    stop_words = get_stop_words('italian')
    corpus = df.apply(lambda r: TaggedDocument(words=preprocess(r['risposta'], stop_words), tags=[r.classe]), axis=1)

    '''
    il modello di regressione è già addestrato, ma purtroppo ho riscontrato problemi a caricare i pesi
    di due modelli addestrati in cascata. Se carico entrambi e povo ad usarli allora funziona male.
    Devo trovare una soluzione, in modo da evitare di dovermi caricare il cvs con i dati che in futuro potrebbe essere
    molto pesante.
    Per ora io carico il modello doc2vec addestrato e poi riaddestro il modello logistico per la classificazione finale
    '''

    y_train, X_train = vec_for_learning(model, corpus)
    logreg = LogisticRegression(n_jobs=1, C=1e5)
    logreg.fit(X_train, y_train)

    #codice per il caricamento del modello logistico. Per ora non posso caricare due modelli addestrati a cascata
    #il secondo necessita di essere riaddestrato
    '''
        with open(pkl_filename, 'rb') as file:
        logreg = pickle.load(file)
    '''

    return model, logreg


if __name__ == "__main__":

    #setto le varie path della cartelle dove sono salvati modelli e dati
    path_dir_lezioni = "lezioni_di_prova"
    path_modello = "models"
    path_data = "data/risposte_utente.csv"

    # inizializzazione dei dizionari. Provo con il word2vec invece del bow sui documenti
    model, logreg = carica_modello(path_modello, path_data)

    # creazione dei thread
    '''
    il primo thread serve per ascoltare l'utente
    il secondo thread serve per analizzare il testo contenente la richiesta utente
    '''

    thread1 = Listener_thread()
    thread2 = Speaker_thread(model, logreg, path_dir_lezioni)

    #avvio i thread
    thread1.start()
    thread2.start()

    #chiudo i thread
    thread1.join()
    thread2.join()
